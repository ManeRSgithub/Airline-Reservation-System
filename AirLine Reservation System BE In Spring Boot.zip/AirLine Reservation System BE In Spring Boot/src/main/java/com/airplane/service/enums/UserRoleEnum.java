package com.airplane.service.enums;

public enum UserRoleEnum {
    USER,
    ADMIN,
    DELIVERY_BOY
}
